/* Monadic analyses - FDI national diversity and Breach of contract */

#delimit;
xtreg
ondd_exp
l.hi_natstock
l.lninstock
l.bits_running
l.lnx_fm_wto
l.polconiii
l.lngdppc 
l.gdp_growth
year_*
if oecd==0 & hi_natstock!=1, fe robust cluster(wbcode);
estimates store e1;

#delimit;
xtreg
ICRG
l.hi_natstock
l.lninstock
l.bits_running
l.lnx_fm_wto
l.polconiii
l.lngdppc 
l.gdp_growth 
year_*
if oecd==0 & hi_natstock!=1, fe robust cluster(wbcode);
estimates store e2;

/* only region FE due to data constraints */
#delimit;
xtreg
EIU
l.hi_natstock
l.bits_running
l.lninstock
l.lnx_fm_wto
l.polconiii
l.lngdppc 
l.gdp_growth 
year_*
region_*
if oecd==0 & hi_natstock!=1, robust cluster(wbcode);
estimates store e3;

estout e1 e2 e3, starlevels(* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par))
stats( N, fmt(%9.0f))
legend label collabels (none) varlabels (_cons Constant);

sum ondd_exp ICRG EIU hi_natstock bits_running lninstock lnx_fm_wto polconiii lngdppc
gdp_growth;


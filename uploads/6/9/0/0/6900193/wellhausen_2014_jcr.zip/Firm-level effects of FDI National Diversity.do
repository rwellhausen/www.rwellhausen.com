/* Firm-level effects of FDI National Diversity 
use: Firm-level data.dta */

#delimit;
logit arrears hi_natstock
sector_1 sector_3 sector_4 export_1 region_*
if hi_natstock!=1,
robust cluster(wbcode);
estimates store e1;

#delimit;
logit arrears hi_natstock foreign
sector_1 sector_3 sector_4 export_1 region_*
if hi_natstock!=1,
robust cluster(wbcode);
estimates store e2;

#delimit;
logit arrears c.hi_natstock i.foreign foreign#c.hi_natstock
i.sector_1 i.sector_3 i.sector_4 i.export_1 region_*
if hi_natstock!=1,
robust cluster(wbcode);
estimates store e3;
margins, dydx(foreign) at(hi_natstock=(1(.5)4)) level(90);
marginsplot, scheme(s2mono);

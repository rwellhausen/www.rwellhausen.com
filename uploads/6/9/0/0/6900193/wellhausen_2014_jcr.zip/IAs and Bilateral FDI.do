/* IA effects on bilateral FDI */



sort hhNUM year

/* W/O IAs */
#delimit;
xtreg lnnetfdi
l.bit_force
l.lntrade_hh
l.polconiii
l.breachrisks
l.lnhost_gdppc
l.host_growth
l.lnpop_host
l.kaopen
l.lnhome_gdppc
l.home_growth
year_*
if oecd==0, 
fe robust cluster(hhNUM);
estimates store e1;

sum iia iiaother iia2 iiaother2 iia5 iiaother5
lnnetfdi bit_force lntrade_hh polconiii breachrisks lnhost_gdppc host_growth lnpop_host kaopen
lnhome_gdppc home_growth if e(sample);

/* IA tests - one year */
#delimit;
xtreg lnnetfdi
l.iia l.iiaother
l.bit_force
l.lntrade_hh
l.polconiii
l.breachrisks
l.lnhost_gdppc
l.host_growth
l.lnpop_host
l.kaopen
l.lnhome_gdppc
l.home_growth
year_*
if oecd==0, 
fe robust cluster(hhNUM);
estimates store e2;

/* IA tests - two years */
#delimit;
xtreg lnnetfdi
l.iia2 l.iiaother2
l.bit_force
l.lntrade_hh
l.polconiii
l.breachrisks
l.lnhost_gdppc
l.host_growth
l.lnpop_host
l.kaopen
l.lnhome_gdppc
l.home_growth
year_*
if oecd==0, 
fe robust cluster(hhNUM);
estimates store e3;

/* IA tests - five years */
#delimit;
xtreg lnnetfdi
l.iia5 l.iiaother5
l.bit_force
l.lntrade_hh
l.polconiii
l.breachrisks
l.lnhost_gdppc
l.host_growth
l.lnpop_host
l.kaopen
l.lnhome_gdppc
l.home_growth
year_*
if oecd==0, 
fe robust cluster(hhNUM);
estimates store e4;

estout e1 e2 e3 e4, starlevels(* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par))
stats( N, fmt(%9.0f))
legend label collabels (none) varlabels (_cons Constant);


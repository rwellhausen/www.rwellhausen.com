
#delimit;
sort wbind_num year;

/* Main results with main data set */

local controls l.rdexpend l.lnfdi l.trade l.kaopen l.lngdppc l.polity2 year_*;

xtreg lnrd `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e1;

sum lnrd lnva lnsales lnexports rdexpend lnfdi trade 
kaopen lngdppc polity2
if e(sample);

xtreg lnrd l.lnva `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e2;

xtreg lnrd l.lnsales `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e3;

xtreg lnrd l.lnexports `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e4;

xtreg lnrd l.lnva l.lnsales l.lnexports `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e5;

  #delimit;
 estout e1 e2 e3 e4 e5, starlevels(* .1 ** .05 *** .01) 
 cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)));

 /* DiD */
#delimit;
local controls d.rdexpend d.lnfdi d.trade d.kaopen d.lngdppc d.polity2 year_*;

xtreg d.lnrd `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e1;

xtreg d.lnrd d.lnva `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e2;

xtreg d.lnrd d.lnsales `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e3;

xtreg d.lnrd d.lnexports `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e4;

xtreg d.lnrd d.lnva d.lnsales d.lnexports `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e5;

  #delimit;
 estout e1 e2 e3 e4 e5, starlevels(* .1 ** .05 *** .01) 
 cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)));

 
 /* Education */
#delimit;
local controls l.rdexpend l.lnfdi l.trade l.kaopen l.lngdppc l.polity2 year_*;

 xtreg l.lnrd l.lnva l.secondarylabor `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e1;

xtreg l.lnrd l.lnva l.collegelabor `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e2;

xtreg l.lnrd l.lnva l.rduni `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e3;

  #delimit;
 estout e1 e2 e3, starlevels(* .1 ** .05 *** .01) 
 cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)));
 
===
** change to "incentives master" data set

/* Adding presence of incentive
gen incentive2 = l.incentive + l2.incentive
gen incentive3 = l.incentive + l2.incentive + l3.incentive
*/

#delimit;
local controls l.rdexpend l.lnfdi l.trade l.kaopen 
l.lngdppc l.polity2 year_*;

xtreg l.lnrd l.lnva l.incentive `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e1;

xtreg l.lnrd l.lnva incentive2 `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e2;

xtreg l.lnrd l.lnva incentive3 `controls'
if ind_agg!="." | ind_agg!=".all"
, fe robust cluster(wbind);
estimates store e3;

  #delimit;
 estout e1 e2 e3, starlevels(* .1 ** .05 *** .01) 
 cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)));

clear;




/* Under One Roof: Survey Results  
please contact Rachel Wellhausen (rwellhausen@utexas.edu) with questions */

/* Table 4B: Descriptive statistics */

tab prussup
bysort prussup: sum breachavg 
bysort prussup: sum natlavg  
bysort prussup: sum allavg  

/* Main results */

tobit breachavg prussup_* , ll(1) ul(4) robust
estimates store e1

tobit breachavg prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust 
estimates store e2

tobit natlavg prussup_* , ll(1) ul(4) robust
estimates store e3

tobit natlavg prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust
estimates store e4

tobit allavg prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust 
estimates store e5

estout e1 e2 e3 e4 e5, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))

/* Online Appendix: Disaggregated industry categories - general services excluded */

tobit breachavg prussup_*  ind_2 ind_3 ind_9 ind_10 ind_1_5 ind_4 ind_6 ind_11, ll(1) ul(4) robust 
estimates store e1

tobit natlavg prussup_* ind_2 ind_3 ind_9 ind_10 ind_1_5 ind_4 ind_6 ind_11, ll(1) ul(4) robust 
estimates store e2

tobit allavg prussup_* ind_2 ind_3 ind_9 ind_10 ind_1_5 ind_4 ind_6 ind_11, ll(1) ul(4) robust 
estimates store e3

estout e1 e2 e3, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))

/* Robustness: ordered logit 
Results of interest in Table 5 are robust to ordered logit specifications, where the dependent 
variables are the sums of respondents� concerns about the relevant issue.*/

ologit breachsum prussup_*, robust 
estimates store e1

ologit breachsum prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, robust 
estimates store e2

ologit natlsum prussup_*, robust 
estimates store e3

ologit natlsum prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, robust 
estimates store e4

ologit allsum prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, robust 
estimates store e5

estout e1 e2 e3 e4 e5, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))

/* Robustness: Percent Russian suppliers in 2 categories
Results of interest in Table 5 are robust to replacing the proportion Russian suppliers with a dichotomous 
measure (=1 where <50%; 0% dropped as missing). */

tobit breachavg rob_prussup, ll(1) ul(4) 
estimates store e1

tobit breachavg rob_prussup jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust 
estimates store e2

tobit natlavg rob_prussup, ll(1) ul(4) robust
estimates store e3

tobit natlavg rob_prussup jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust
estimates store e4

tobit allavg rob_prussup jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust 
estimates store e5

estout e1 e2 e3 e4 e5, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))


/* Robustness: SOE interactions - split sample
Results of interest in Table 5 are robust to restricting the sample to only 
firms with business interactions with Russian SOEs monthly or more often. */

tobit breachavg prussup_* if statebiz_01==1, ll(1) ul(4) 
estimates store e1

tobit breachavg prussup_* jv rusmktshr_01 size_* pruscust_01 immobile manuf yrs if statebiz_01==1, ll(1) ul(4) robust
estimates store e2

tobit natlavg prussup_* if statebiz_01==1, ll(1) ul(4) robust 
estimates store e3

tobit natlavg prussup_* jv rusmktshr_01 size_* pruscust_01 immobile manuf yrs if statebiz_01==1, ll(1) ul(4) robust 
estimates store e4

tobit allavg prussup_* jv rusmktshr_01 size_* pruscust_01 immobile manuf yrs if statebiz_01==1, ll(1) ul(4) robust 
estimates store e5

estout e1 e2 e3 e4 e5, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))

/* Robustness: Absolute number of Russian suppliers 
Results of interest in Table 5 are not robust to using a measure of the absolute number 
of Russian suppliers (=1 if 10 or more Russian suppliers). */

tobit breachavg russup_01, ll(1) ul(4) 
estimates store e1

tobit breachavg russup_01  jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust
estimates store e2

tobit natlavg russup_01, ll(1) ul(4) 
estimates store e3

tobit natlavg russup_01 jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust
estimates store e4

tobit allavg russup_01 jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs, ll(1) ul(4) robust
estimates store e5

estout e1 e2 e3 e4 e5, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))

/* Robustness: Results are robust to dropping observations where the percentage of Russian suppliers is 0. */

tobit breachavg prussup_* if prussup_1!=1, ll(1) ul(4) robust
estimates store e1

tobit breachavg prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs if prussup_1!=1, ll(1) ul(4) robust 
estimates store e2

tobit natlavg prussup_* if prussup_1!=1, ll(1) ul(4) robust
estimates store e3

tobit natlavg prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs if prussup_1!=1, ll(1) ul(4) robust
estimates store e4

tobit allavg prussup_* jv statebiz_01 rusmktshr_01 size_* pruscust_01 immobile manuf yrs if prussup_1!=1, ll(1) ul(4) robust 
estimates store e5

estout e1 e2 e3 e4 e5, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))

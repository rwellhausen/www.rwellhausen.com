/* Under One Roof: Cross-national data 
Please contact Rachel Wellhausen (rwellhausen@utexas.edu) with questions. */

** Using Observational data RR.dta

** TSCS results (developing countries - non-OECD)

** Model (1) US-origin IA and related party trade
xtreg iafdi_1000 l.iafdi_1000 l.lnexp_rel l.polity2 bit_force /// 
year_*, cluster(wbcode) robust

** Model (2) US-origin IA and intermediate good exports to US
xtreg iafdi_1000 l.iafdi_1000 l.lnexp l.polity2 bit_force ///
year_*, cluster(wbcode) robust

** Collapsed data - using Observational data RR.dta

collapse iafdi_1000 l.lnexp_rel l.lnexp l.polity2 bit_force, by(wbcode)

** Model (3) Related party trade
reg iafdi_1000 Llnexp_rel Lpolity2 bit_force, robust

** Model (4) Intermediate good exports to US
reg iafdi_1000 Llnexp Lpolity2 bit_force, robust 


******************************
==

** Online Appendix
** Using Observational data - NAICS.dta

** Model (A1) Related party trade by industry
xtreg iafdi_1000 l.iafdi_1000 l.lnexp_rel l.polity2 bit_force naics_1 naics_2 year_*, cluster(wbcodeNUM) robust
est store e1
estout e1, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))


** Collapsed data - using Observational data - NAICS.dta

** Model (A2)
collapse iafdi_1000 l.lnexp_rel naics_* l.polity2 bit_force wbcodeNUM, by(wbnaics)

reg iafdi_1000 Llnexp_rel Lpolity2 bit_force naics_1 naics_2, cluster(wbcodeNUM) robust
est store e1
estout e1, starlevels (* .1 ** .05 *** .01) cells(b(star fmt(%9.3f)) se(par)) stats(r2 N, fmt(%9.3f %9.0f))



